# unzipper3000

## starting the script
You can either run this script singlethreaded with `./unzipper3000` or multithreaded with `./multithreaded.sh` which will be way faster. 